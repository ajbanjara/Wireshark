I have permission to release these capture files. They have been modified to remove sensitive information such as e.g. VIN and binary data.
